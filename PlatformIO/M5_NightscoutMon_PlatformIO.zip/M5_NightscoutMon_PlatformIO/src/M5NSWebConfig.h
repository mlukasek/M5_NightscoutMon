#ifndef _M5NSWEBCONFIG_H
#define _M5NSWEBCONFIG_H

void handleRoot();
void handleUpdate();
void handleSwitchConfig();
void handleEditConfigItem();
void handleGetEditConfigItem();
void handleSaveConfig();
void handleNotFound();

#endif
